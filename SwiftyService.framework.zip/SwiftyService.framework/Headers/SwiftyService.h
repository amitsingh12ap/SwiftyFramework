//
//  SwiftyService.h
//  SwiftyService
//
//  Created by Amit Singh on 09/08/19.
//  Copyright © 2019 Amit Singh. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SwiftyService.
FOUNDATION_EXPORT double SwiftyServiceVersionNumber;

//! Project version string for SwiftyService.
FOUNDATION_EXPORT const unsigned char SwiftyServiceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftyService/PublicHeader.h>


